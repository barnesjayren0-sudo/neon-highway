# Neon Dash — Combined Mobile Godot 4 Project (Neon Highway)

This is one working, mobile-first **Godot 4.3** project, built by combining **everything** from
`Combine_these.zip` (the `neon` + `stellar` Android exports from the archive).

## Quick facts

- **Engine:** Godot 4.3.x (project sources were compiled by Godot 4.3-stable)
- **Genre:** offline 3D endless runner, designed for Android (landscape)
- **Renderer:** `Mobile` (mobile-friendly rendering method)
- **Main scene:** `res://scenes/boot/Splash.tscn`
- **Export preset:** `Android` (ARMv7 + ARM64, immersive mode, vibrate, ETC2/ASTC textures)
- **Autoloads:** 14 (`Constants`, `EventBus`, `Localization`, `SaveManager`, `SettingsManager`,
  `AudioManager`, `GameManager`, `PoolManager`, `StatisticsManager`, `AchievementManager`,
  `MissionManager`, `DailyRewardManager`, `SceneRouter`, `PerfOverlay`)

## Open and run

1. Install **Godot 4.3** (standard, not .NET).
2. `Project > Import…` and select `project.godot` (Godot imports assets on first open).
3. Press **F5** — the game boots through `Splash.tscn` into the main menu.
4. **Android export:** `Project > Export… > Android`, install the Android Build Template,
   configure your SDK/JDK/keystore, then export. The preset is already configured.

Controls: arrow keys / A-D for lanes, Space jump, S slide, Shift dash, Esc pause.
(Touch controls are implemented in `scripts/gameplay/TouchInput.gd`.)

## Project layout

```text
├── project.godot            # restored from the original project.binary
├── export_presets.cfg       # Android preset (mobile)
├── scenes/                  # 19 scenes: boot, game, gameplay, world, ui, collectibles, obstacles, powerups
├── scripts/                 # 34 game scripts (autoload, gameplay, ui, world, data…)
├── localization/            # translations.csv + 6 compiled locales (en, de, es, fr, hi, pt)
├── assets/
│   ├── icons/icon.svg       # project/app icon
│   └── icons/android/       # launcher icons (see below)
└── addons/gut/              # GUT test framework (as shipped in the source export)
```

## How this was combined (provenance)

**`neon/` — the game (primary source).** A complete Godot 4.3 Android export of "Neon Dash"
(package `com.neondash.game`, version 0.2.1). All 104 GDScript files were recovered from
compiled bytecode (`.gdc`) and all 19 game scenes from compiled scenes (`.scn`) with
[GDRE Tools](https://github.com/GDRETools/gdsdecomp); `project.godot` was restored from
`project.binary`. The game's own launcher icons were recovered from the APK resources:
`assets/icons/android/icon_192.png`, `adaptive_foreground_432.png`, `adaptive_background_432.png`.

**`stellar/` — the other export (secondary source).** A Godot 4.7 Android app shell for
"Stellar Stones" (package `org.stellarstones.sh`) containing **no Godot engine payload or game
data** — only Android packaging resources. Everything mergeable from it was folded into this project:

- `org.godotengine.rendering.method = mobile` → the project now uses the **Mobile renderer**.
- Adaptive launcher icons and splash art → converted from the APK's WebP resources to PNGs in
  `assets/icons/android/stellar/` (`icon_192.png`, `adaptive_foreground_432.png`,
  `adaptive_background_432.png`, `adaptive_monochrome_432.png`, `splash_icon_512.png`,
  `splash_branding_100.png`).
- Its mobile packaging choices informed the export preset (landscape, immersive mode,
  ARM architectures, vibrate/immersive intent from the engine command line `_cl_`).

## Recovery notes

- **GDRE report:** 104/104 scripts decompiled, 161/162 resources converted. The single failure was
  GUT's editor-only bitmap font (`addons/gut/source_code_pro.fnt`); its dangling `.import` file was
  removed and nothing references it.
- **Defect fixed during verification:** `PoolManager.acquire()` returned pooled nodes while they
  were still parented to the pool container, so every reused chunk/obstacle/collectible failed to
  attach (`"already has a parent"` errors at runtime). `acquire()` now detaches a node from its
  current parent before returning it.
- **Audio:** `AudioManager` references `res://assets/audio/...`, but the source export contains no
  audio files. The manager guards every load with `ResourceLoader.exists()` and degrades gracefully
  (silent game, no crashes). Drop the referenced files into `assets/audio/` to enable audio.
- **`addons/gut`** is included exactly as it was in the source export (test framework; no test
  scripts are present in the archive).
- **`.godot/`** is intentionally not shipped — Godot regenerates the import cache on first open.

## Verification performed (Godot 4.3-stable, headless)

| Check | Result |
| --- | --- |
| Editor import pass (`--editor --quit`) | **0 errors**, 61 assets imported |
| Boot run (`--quit-after 600`) | **0 errors** |
| All 19 scenes load + instantiate | **19/19 OK**, 0 failed |
| Scripted gameplay run (Game scene + simulated input ~12 s) | score 204, distance 204.3, **0 errors** |
| Android export preset parses (`--export-release "Android"`) | preset resolved (export stops at missing SDK, as expected) |
