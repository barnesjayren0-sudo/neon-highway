

















extends Node2D

const EXIT_OK = 0
const EXIT_ERROR = 1

var Gut = load("res://addons/gut/gut.gd")
var ResultExporter = load("res://addons/gut/result_exporter.gd")
var GutConfig = load("res://addons/gut/gut_config.gd")

var runner_json_path = null
var result_bbcode_path = null
var result_json_path = null

var lgr = GutUtils.get_logger()
var gut_config = null

var _hid_gut = null;

var gut = _hid_gut:
	get:
		if (_hid_gut == null):
			_hid_gut = Gut.new()
		return _hid_gut
	set(val):
		_hid_gut = val
var _wrote_results = false





var ran_from_editor = true

@onready var _gut_layer = $GutLayer
@onready var _gui = $GutLayer / GutScene


func _ready():
	GutUtils.WarningsManager.apply_warnings_dictionary(
		GutUtils.warnings_at_start)
	GutUtils.LazyLoader.load_all()




	if (ran_from_editor):
		_run_from_editor()


func _exit_tree():
	if ( !_wrote_results and ran_from_editor):
		_write_results_for_gut_panel()


func _run_from_editor():
	var GutEditorGlobals = load("res://addons/gut/gui/editor_globals.gd")
	runner_json_path = GutUtils.nvl(runner_json_path, GutEditorGlobals.editor_run_gut_config_path)
	result_bbcode_path = GutUtils.nvl(result_bbcode_path, GutEditorGlobals.editor_run_bbcode_results_path)
	result_json_path = GutUtils.nvl(result_json_path, GutEditorGlobals.editor_run_json_results_path)

	if (gut_config == null):
		gut_config = GutConfig.new()
		gut_config.load_options(runner_json_path)

	call_deferred("run_tests")


func _setup_gui(show_gui):
	if (show_gui):
		_gui.gut = gut
		var printer = gut.logger.get_printer("gui")
		printer.set_textbox(_gui.get_textbox())
	else:
		gut.logger.disable_printer("gui", true)
		_gui.visible = false

	var opts = gut_config.options
	_gui.set_font_size(opts.font_size)
	_gui.set_font(opts.font_name)
	if (opts.font_color != null and opts.font_color.is_valid_html_color()):
		_gui.set_default_font_color(Color(opts.font_color))
	if (opts.background_color != null and opts.background_color.is_valid_html_color()):
		_gui.set_background_color(Color(opts.background_color))

	_gui.set_opacity(min(1.0, float(opts.opacity) / 100))
	_gui.use_compact_mode(opts.compact_mode)


func _write_results_for_gut_panel():
	var content = _gui.get_textbox().get_parsed_text()
	var f = FileAccess.open(result_bbcode_path, FileAccess.WRITE)
	if (f != null):
		f.store_string(content)
		f = null
	else:
		push_error("Could not save bbcode, result = ", FileAccess.get_open_error())

	var exporter = ResultExporter.new()


	var _f_result = exporter.write_json_file(gut, result_json_path)
	_wrote_results = true


func _handle_quit(should_exit, should_exit_on_success, override_exit_code = EXIT_OK):
	var quitting_time = should_exit or \
	(should_exit_on_success and gut.get_fail_count() == 0)

	if ( !quitting_time):
		if (should_exit_on_success):
			lgr.log("There are failing tests, exit manually.")
		_gui.use_compact_mode(false)
		return




	var exit_code = GutUtils.nvl(override_exit_code, EXIT_OK)

	if (gut.get_fail_count() > 0):
		exit_code = EXIT_ERROR


	var post_hook_inst = gut.get_post_run_script_instance()
	if (post_hook_inst != null and post_hook_inst.get_exit_code() != null):
		exit_code = post_hook_inst.get_exit_code()

	quit(exit_code)


func _end_run(override_exit_code = EXIT_OK):
	if (ran_from_editor):
		_write_results_for_gut_panel()

	_handle_quit(gut_config.options.should_exit, 
		gut_config.options.should_exit_on_success, 
		override_exit_code)





func _on_tests_finished():
	_end_run()





func run_tests(show_gui = true):
	_setup_gui(show_gui)

	if (gut_config.options.dirs.size() + gut_config.options.tests.size() == 0):
		var err_text = "You do not have any directories configrued, so GUT doesn't know where to find the tests.  Tell GUT where to find the tests and GUT shall run the tests."
		lgr.error(err_text)
		push_error(err_text)
		_end_run(EXIT_ERROR)
		return

	var install_check_text = GutUtils.make_install_check_text()
	if (install_check_text != GutUtils.INSTALL_OK_TEXT):
		print("\n\n", GutUtils.version_numbers.get_version_text())
		lgr.error(install_check_text)
		push_error(install_check_text)
		_end_run(EXIT_ERROR)
		return

	gut.add_children_to = self
	if (gut.get_parent() == null):
		if (gut_config.options.gut_on_top):
			_gut_layer.add_child(gut)
		else:
			add_child(gut)

	gut.end_run.connect(_on_tests_finished)

	gut_config.apply_options(gut)
	var run_rest_of_scripts = gut_config.options.unit_test_name == ""

	gut.test_scripts(run_rest_of_scripts)


func set_gut_config(which):
	gut_config = which



func get_gut():
	return gut


func quit(exit_code):


	_gui.set_title("Exiting")
	await get_tree().process_frame

	lgr.info(str("Exiting with code ", exit_code))
	get_tree().quit(exit_code)
