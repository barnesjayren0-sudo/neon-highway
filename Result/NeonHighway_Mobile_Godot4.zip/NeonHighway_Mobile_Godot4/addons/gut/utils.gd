@tool
class_name GutUtils
extends Object

const GUT_METADATA = "__gutdbl"



enum DOUBLE_STRATEGY{
	INCLUDE_NATIVE, 
	SCRIPT_ONLY, 
}

enum DIFF{
	DEEP, 
	SIMPLE
}

const TEST_STATUSES = {
	NO_ASSERTS = "no asserts", 
	SKIPPED = "skipped", 
	NOT_RUN = "not run", 
	PENDING = "pending", 


	FAILED = "fail", 
	PASSED = "pass"
}

const DOUBLE_TEMPLATES = {
	FUNCTION = "res://addons/gut/double_templates/function_template.txt", 
	INIT = "res://addons/gut/double_templates/init_template.txt", 
	SCRIPT = "res://addons/gut/double_templates/script_template.txt", 
}


static var GutScene = load("res://addons/gut/GutScene.tscn")
static var LazyLoader = load("res://addons/gut/lazy_loader.gd")
static var VersionNumbers = load("res://addons/gut/version_numbers.gd")
static var WarningsManager = load("res://addons/gut/warnings_manager.gd")






static var AutoFree = LazyLoader.new("res://addons/gut/autofree.gd"):
	get: return AutoFree.get_loaded()
	set(val): pass
static var Awaiter = LazyLoader.new("res://addons/gut/awaiter.gd"):
	get: return Awaiter.get_loaded()
	set(val): pass
static var Comparator = LazyLoader.new("res://addons/gut/comparator.gd"):
	get: return Comparator.get_loaded()
	set(val): pass
static var CollectedTest = LazyLoader.new("res://addons/gut/collected_test.gd"):
	get: return CollectedTest.get_loaded()
	set(val): pass
static var CollectedScript = LazyLoader.new("res://addons/gut/collected_script.gd"):
	get: return CollectedScript.get_loaded()
	set(val): pass
static var CompareResult = LazyLoader.new("res://addons/gut/compare_result.gd"):
	get: return CompareResult.get_loaded()
	set(val): pass
static var DiffTool = LazyLoader.new("res://addons/gut/diff_tool.gd"):
	get: return DiffTool.get_loaded()
	set(val): pass
static var Doubler = LazyLoader.new("res://addons/gut/doubler.gd"):
	get: return Doubler.get_loaded()
	set(val): pass
static var DynamicGdScript = LazyLoader.new("res://addons/gut/dynamic_gdscript.gd"):
	get: return DynamicGdScript.get_loaded()
	set(val): pass
static var Gut = LazyLoader.new("res://addons/gut/gut.gd"):
	get: return Gut.get_loaded()
	set(val): pass
static var GutConfig = LazyLoader.new("res://addons/gut/gut_config.gd"):
	get: return GutConfig.get_loaded()
	set(val): pass
static var HookScript = LazyLoader.new("res://addons/gut/hook_script.gd"):
	get: return HookScript.get_loaded()
	set(val): pass
static var InnerClassRegistry = LazyLoader.new("res://addons/gut/inner_class_registry.gd"):
	get: return InnerClassRegistry.get_loaded()
	set(val): pass
static var InputFactory = LazyLoader.new("res://addons/gut/input_factory.gd"):
	get: return InputFactory.get_loaded()
	set(val): pass
static var InputSender = LazyLoader.new("res://addons/gut/input_sender.gd"):
	get: return InputSender.get_loaded()
	set(val): pass
static var JunitXmlExport = LazyLoader.new("res://addons/gut/junit_xml_export.gd"):
	get: return JunitXmlExport.get_loaded()
	set(val): pass
static var Logger = LazyLoader.new("res://addons/gut/logger.gd"):
	get: return Logger.get_loaded()
	set(val): pass
static var MethodMaker = LazyLoader.new("res://addons/gut/method_maker.gd"):
	get: return MethodMaker.get_loaded()
	set(val): pass
static var OneToMany = LazyLoader.new("res://addons/gut/one_to_many.gd"):
	get: return OneToMany.get_loaded()
	set(val): pass
static var OrphanCounter = LazyLoader.new("res://addons/gut/orphan_counter.gd"):
	get: return OrphanCounter.get_loaded()
	set(val): pass
static var ParameterFactory = LazyLoader.new("res://addons/gut/parameter_factory.gd"):
	get: return ParameterFactory.get_loaded()
	set(val): pass
static var ParameterHandler = LazyLoader.new("res://addons/gut/parameter_handler.gd"):
	get: return ParameterHandler.get_loaded()
	set(val): pass
static var Printers = LazyLoader.new("res://addons/gut/printers.gd"):
	get: return Printers.get_loaded()
	set(val): pass
static var ResultExporter = LazyLoader.new("res://addons/gut/result_exporter.gd"):
	get: return ResultExporter.get_loaded()
	set(val): pass
static var ScriptCollector = LazyLoader.new("res://addons/gut/script_parser.gd"):
	get: return ScriptCollector.get_loaded()
	set(val): pass
static var Spy = LazyLoader.new("res://addons/gut/spy.gd"):
	get: return Spy.get_loaded()
	set(val): pass
static var Strutils = LazyLoader.new("res://addons/gut/strutils.gd"):
	get: return Strutils.get_loaded()
	set(val): pass
static var Stubber = LazyLoader.new("res://addons/gut/stubber.gd"):
	get: return Stubber.get_loaded()
	set(val): pass
static var StubParams = LazyLoader.new("res://addons/gut/stub_params.gd"):
	get: return StubParams.get_loaded()
	set(val): pass
static var Summary = LazyLoader.new("res://addons/gut/summary.gd"):
	get: return Summary.get_loaded()
	set(val): pass
static var Test = LazyLoader.new("res://addons/gut/test.gd"):
	get: return Test.get_loaded()
	set(val): pass
static var TestCollector = LazyLoader.new("res://addons/gut/test_collector.gd"):
	get: return TestCollector.get_loaded()
	set(val): pass
static var ThingCounter = LazyLoader.new("res://addons/gut/thing_counter.gd"):
	get: return ThingCounter.get_loaded()
	set(val): pass


static var avail_fonts = ["AnonymousPro", "CourierPrime", "LobsterTwo", "Default"]

static var version_numbers = VersionNumbers.new(

	"9.3.0", 

	"4.2.0"
)


static var warnings_at_start: = {
	exclude_addons = true
}

static var warnings_when_loading_test_scripts: = {
	enable = false
}








static var _test_mode = false
static var _lgr = null
static func get_logger():
	if (_test_mode):
		return Logger.new()
	else:
		if (_lgr == null):
			_lgr = Logger.new()
		return _lgr


static var _dyn_gdscript = DynamicGdScript.new()
static func create_script_from_source(source, override_path = null):
	var DynamicScript = _dyn_gdscript.create_script_from_source(source, override_path)

	if (typeof(DynamicScript) == TYPE_INT):
		var l = get_logger()
		l.error(str("Could not create script from source.  Error:  ", DynamicScript))
		l.info(str("Source Code:\n", add_line_numbers(source)))

	return DynamicScript


static func godot_version_string():
	return version_numbers.make_godot_version_string()


static func is_godot_version(expected):
	return VersionNumbers.VerNumTools.is_godot_version_eq(expected)


static func is_godot_version_gte(expected):
	return VersionNumbers.VerNumTools.is_godot_version_gte(expected)


const INSTALL_OK_TEXT = "Everything checks out"
static func make_install_check_text(template_paths = DOUBLE_TEMPLATES, ver_nums = version_numbers):
	var text = INSTALL_OK_TEXT
	if ( !FileAccess.file_exists(template_paths.FUNCTION) or 
		!FileAccess.file_exists(template_paths.INIT) or 
		!FileAccess.file_exists(template_paths.SCRIPT)):

		text = "One or more GUT template files are missing.  If this is an exported project, you must include *.txt files in the export to run GUT.  If it is not an exported project then reinstall GUT."
	elif ( !ver_nums.is_godot_version_valid()):
		text = ver_nums.get_bad_version_text()

	return text


static func is_install_valid(template_paths = DOUBLE_TEMPLATES, ver_nums = version_numbers):
	return make_install_check_text(template_paths, ver_nums) == INSTALL_OK_TEXT
































static func get_enum_value(thing, e, default = null):
	var to_return = default

	if (typeof(thing) == TYPE_STRING and str(thing.to_int()) == thing):
		thing = thing.to_int()
	elif (typeof(thing) == TYPE_FLOAT):
		thing = int(thing)

	if (typeof(thing) == TYPE_STRING):
		var converted = thing.to_upper().replace(" ", "_")
		if (e.keys().has(converted)):
			to_return = e[converted]
	else:
		if (e.values().has(thing)):
			to_return = thing

	return to_return





static func nvl(value, if_null):
	if (value == null):
		return if_null
	else:
		return value




static func pretty_print(dict, indent = "  "):
	print(JSON.stringify(dict, indent))




static func print_properties(props, thing, print_all_meta = false):
	for i in range(props.size()):
		var prop_name = props[i].name
		var prop_value = thing.get(props[i].name)
		var print_value = str(prop_value)
		if (print_value.length() > 100):
			print_value = print_value.substr(0, 97) + "..."
		elif (print_value == ""):
			print_value = "EMPTY"

		print(prop_name, " = ", print_value)
		if (print_all_meta):
			print("  ", props[i])









static func get_scene_script_object(scene):
	var state = scene.get_state()
	var to_return = null
	var root_node_path = NodePath(".")
	var node_idx = 0

	while (node_idx < state.get_node_count() and to_return == null):
		if (state.get_node_path(node_idx) == root_node_path):
			for i in range(state.get_node_property_count(node_idx)):
				if (state.get_node_property_name(node_idx, i) == "script"):
					to_return = state.get_node_property_value(node_idx, i)

		node_idx += 1

	return to_return









static func is_freed(obj):
	var wr = weakref(obj)
	return !(wr.get_ref() and str(obj) != "<Freed Object>")





static func is_not_freed(obj):
	return !is_freed(obj)





static func is_double(obj):
	var to_return = false
	if (typeof(obj) == TYPE_OBJECT and is_instance_valid(obj)):
		to_return = obj.has_method("__gutdbl_check_method__")
	return to_return





static func is_native_class(thing):
	var it_is = false
	if (typeof(thing) == TYPE_OBJECT):
		it_is = str(thing).begins_with("<GDScriptNativeClass#")
	return it_is





static func is_instance(obj):
	return typeof(obj) == TYPE_OBJECT and \
	!is_native_class(obj) and \
	!obj.has_method("new") and \
	!obj.has_method("instantiate")





static func is_gdscript(obj):
	return typeof(obj) == TYPE_OBJECT and str(obj).begins_with("<GDScript#")








static func is_inner_class(obj):
	return is_gdscript(obj) and obj.resource_path == ""





static func extract_property_from_array(source, property):
	var to_return = []
	for i in (source.size()):
		to_return.append(source[i].get(property))
	return to_return





static func is_null_or_empty(text):
	return text == null or text == ""






static func get_native_class_name(thing):
	var to_return = null
	if (is_native_class(thing)):
		var newone = thing.new()
		to_return = newone.get_class()
		if ( !newone is RefCounted):
			newone.free()
	return to_return





static func write_file(path, content):
	var f = FileAccess.open(path, FileAccess.WRITE)
	if (f != null):
		f.store_string(content)
	f = null;

	return FileAccess.get_open_error()





static func get_file_as_text(path):
	var to_return = ""
	var f = FileAccess.open(path, FileAccess.READ)
	if (f != null):
		to_return = f.get_as_text()
	else:
		var err = FileAccess.get_open_error()
		_lgr.error(str("Could not open file ", path, ".  Error ", err))
	f = null
	return to_return







static func search_array_idx(ar, prop_method, value):
	var found = false
	var idx = 0

	while (idx < ar.size() and !found):
		var item = ar[idx]
		var prop = item.get(prop_method)
		if ( !(prop is Callable)):
			if (item.get(prop_method) == value):
				found = true
		elif (prop != null):
			var called_val = prop.call()
			if (called_val == value):
				found = true

		if ( !found):
			idx += 1

	if (found):
		return idx
	else:
		return -1







static func search_array(ar, prop_method, value):
	var idx = search_array_idx(ar, prop_method, value)

	if (idx != -1):
		return ar[idx]
	else:
		return null


static func are_datatypes_same(got, expected):
	return !(typeof(got) != typeof(expected) and got != null and expected != null)


static func get_script_text(obj):
	return obj.get_script().get_source_code()










static func dec2bistr(decimal_value, max_bits = 31):
	var binary_string = ""
	var temp
	var count = max_bits

	while (count >= 0):
		temp = decimal_value >> count
		if (temp & 1):
			binary_string = binary_string + "1"
		else:
			binary_string = binary_string + "0"
		count -= 1

	return binary_string


static func add_line_numbers(contents):
	if (contents == null):
		return ""

	var to_return = ""
	var lines = contents.split("\n")
	var line_num = 1
	for line in lines:
		var line_str = str(line_num).lpad(6, " ")
		to_return += str(line_str, " |", line, "\n")
		line_num += 1
	return to_return


static func get_display_size():
	return Engine.get_main_loop().get_viewport().get_visible_rect()
