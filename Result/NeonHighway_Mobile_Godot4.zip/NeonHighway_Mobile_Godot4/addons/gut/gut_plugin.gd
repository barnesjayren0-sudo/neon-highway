@tool
extends EditorPlugin

var _bottom_panel = null

func _version_conversion():
	var EditorGlobals = load("res://addons/gut/gui/editor_globals.gd")
	EditorGlobals.create_temp_directory()

	var VersionConversion = load("res://addons/gut/version_conversion.gd")
	VersionConversion.convert()

func _enter_tree():
	_version_conversion()

	_bottom_panel = preload("res://addons/gut/gui/GutBottomPanel.tscn").instantiate()

	var button = add_control_to_bottom_panel(_bottom_panel, "GUT")
	button.shortcut_in_tooltip = true












	_bottom_panel.set_interface(get_editor_interface())
	_bottom_panel.set_plugin(self)
	_bottom_panel.set_panel_button(button)
	_bottom_panel.load_shortcuts()


func _exit_tree():


	remove_control_from_bottom_panel(_bottom_panel)
	_bottom_panel.free()
