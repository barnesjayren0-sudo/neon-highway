extends Resource
class_name CharacterData






@export var id: StringName = &"runner_default"
@export var display_name: String = "Runner"
@export var description: String = "The classic neon runner."
@export var color: Color = Color(0.0, 0.9, 1.0)

@export var cost_coins: int = 0

@export var cost_gems: int = 0
@export var unlocked_by_default: bool = false

@export var coin_bonus_multiplier: float = 1.0
@export var start_speed_bonus: float = 0.0
