extends Area3D
class_name Obstacle










enum ObstacleType{FULL, JUMP_OVER, SLIDE_UNDER}

@export var obstacle_type: ObstacleType = ObstacleType.FULL
@export var obstacle_id: String = "block"
@export var mesh_instance: MeshInstance3D

var _resolved: bool = false
var _player_ref: Node3D = null


func _ready() -> void :
	collision_layer = Constants.LAYER_OBSTACLE
	collision_mask = Constants.LAYER_PLAYER
	monitoring = true
	if not body_entered.is_connected(_on_body_entered):
		body_entered.connect(_on_body_entered)


func pool_reset() -> void :
	_resolved = false
	_player_ref = null
	monitoring = true
	rotation = Vector3.ZERO


func _on_body_entered(body: Node3D) -> void :
	if _resolved or not body.is_in_group("player"):
		return
	var player: = body as Player
	if player == null:
		return


	if obstacle_type == ObstacleType.SLIDE_UNDER and player.is_sliding():
		_register_near_miss()
		return
	if obstacle_type == ObstacleType.JUMP_OVER and not player.is_on_floor():
		_register_near_miss()
		return
	_resolved = true
	player.hit(obstacle_id)


func _register_near_miss() -> void :
	if _resolved:
		return
	_resolved = true
	StatisticsManager.increment(StatisticsManager.OBSTACLES_DODGED)
	EventBus.near_miss.emit(obstacle_id)


func _despawn() -> void :
	PoolManager.release(self)
