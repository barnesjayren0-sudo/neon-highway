extends Control
class_name CreditsScreen






func _on_back_pressed() -> void :
	AudioManager.play_sfx("button")
	SceneRouter.goto_main_menu()
