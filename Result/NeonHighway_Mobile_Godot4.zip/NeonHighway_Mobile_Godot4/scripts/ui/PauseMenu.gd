extends Control
class_name PauseMenu







func _on_resume_pressed() -> void :
	AudioManager.play_sfx("button")
	var gc: = get_tree().get_first_node_in_group("game_controller")
	if gc and gc.has_method("toggle_pause"):
		gc.toggle_pause()


func _on_restart_pressed() -> void :
	AudioManager.play_sfx("button")
	get_tree().paused = false
	SceneRouter.goto_game()


func _on_menu_pressed() -> void :
	AudioManager.play_sfx("button")
	get_tree().paused = false
	SceneRouter.goto_main_menu()
