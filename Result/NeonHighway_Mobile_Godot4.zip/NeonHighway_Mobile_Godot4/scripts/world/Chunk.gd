extends Node3D
class_name Chunk











var _spawned: Array[Node] = []
@export var ground_mesh: MeshInstance3D


func pool_reset() -> void :
	clear()
	position = Vector3.ZERO



func add_item(item: Node3D, local_pos: Vector3) -> void :
	add_child(item)
	item.position = local_pos
	_spawned.append(item)



func clear() -> void :
	for item in _spawned:
		if is_instance_valid(item):
			PoolManager.release(item)
	_spawned.clear()



func item_count() -> int:
	return _spawned.size()
