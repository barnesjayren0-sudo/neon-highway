extends Node



















const META_SCENE_PATH: = "_pool_scene_path"


var _pools: Dictionary = {}
var _parent: Node


func _ready() -> void :

	_parent = Node.new()
	_parent.name = "PooledObjects"
	add_child(_parent)



func prewarm(scene_path: String, count: int) -> void :
	var pool: = _ensure_pool(scene_path)
	if pool.is_empty():
		return
	while pool["free"].size() < count:
		var inst: = _instantiate(scene_path)
		if inst == null:
			return
		_deactivate(inst)
		pool["free"].append(inst)




func acquire(scene_path: String) -> Node:
	var pool: = _ensure_pool(scene_path)
	if pool.is_empty():
		return null
	var inst: Node
	if pool["free"].is_empty():
		inst = _instantiate(scene_path)
		if inst == null:
			return null
	else:
		inst = pool["free"].pop_back()
	if inst.get_parent() != null:
		inst.get_parent().remove_child(inst)
	pool["in_use"] = int(pool["in_use"]) + 1
	inst.set_meta(META_SCENE_PATH, scene_path)
	if inst.has_method("pool_reset"):
		inst.call("pool_reset")
	inst.process_mode = Node.PROCESS_MODE_INHERIT
	if inst is CanvasItem:
		(inst as CanvasItem).visible = true
	return inst



func release(node: Node) -> void :
	if node == null or not is_instance_valid(node):
		return
	if not node.has_meta(META_SCENE_PATH):
		node.queue_free()
		return
	var scene_path: String = node.get_meta(META_SCENE_PATH)
	var pool: Dictionary = _pools.get(scene_path, {})
	if pool.is_empty():
		node.queue_free()
		return
	if node.get_parent() != null:
		node.get_parent().remove_child(node)
	_deactivate(node)
	pool["free"].append(node)
	pool["in_use"] = maxi(0, int(pool["in_use"]) - 1)



func active_count(scene_path: String) -> int:
	var pool: Dictionary = _pools.get(scene_path, {})
	return int(pool.get("in_use", 0)) if not pool.is_empty() else 0


func free_count(scene_path: String) -> int:
	var pool: Dictionary = _pools.get(scene_path, {})
	return pool["free"].size() if not pool.is_empty() else 0


func _ensure_pool(scene_path: String) -> Dictionary:
	if _pools.has(scene_path):
		return _pools[scene_path]
	if not ResourceLoader.exists(scene_path):
		push_error("PoolManager: scene not found: " + scene_path)
		return {}
	var scene: = ResourceLoader.load(scene_path)
	if not (scene is PackedScene):
		push_error("PoolManager: not a PackedScene: " + scene_path)
		return {}
	var pool: = {"scene": scene, "free": [] as Array[Node], "in_use": 0}
	_pools[scene_path] = pool
	return pool


func _instantiate(scene_path: String) -> Node:
	var pool: Dictionary = _pools.get(scene_path, {})
	if pool.is_empty():
		return null
	var scene: PackedScene = pool["scene"]
	return scene.instantiate()



func _deactivate(node: Node) -> void :
	node.process_mode = Node.PROCESS_MODE_DISABLED
	if node is CanvasItem:
		(node as CanvasItem).visible = false
	_parent.add_child(node)
